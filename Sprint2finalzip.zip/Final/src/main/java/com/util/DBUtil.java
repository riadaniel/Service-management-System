package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	
	static final String URL = "jdbc:derby:C:\\Users\\USER\\MyDB;create=true";
	static final String DRIVERNAME = "org.apache.derby.jdbc.EmbeddedDriver";
    public static Connection getConnection() throws NullPointerException{
    	Connection conn = null;
    	
    	try{
    		Class.forName(DRIVERNAME);
    		conn = DriverManager.getConnection(URL);
    		System.out.println("Connection established.");
    	}
    	catch(ClassNotFoundException e){
    		
    		System.out.println(e.getMessage());
    	}
    	catch(SQLException e){
    		System.out.println(e.getMessage());
    		
    	}
    	  return conn;
    	
    }
  
}
