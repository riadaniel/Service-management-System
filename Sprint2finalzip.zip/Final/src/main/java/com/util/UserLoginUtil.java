package com.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class UserLoginUtil {
	private static final String DB_URL = "jdbc:derby:C:\\Users\\USER\\MyDB;create=true";

	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			con = DriverManager.getConnection(DB_URL);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
}
