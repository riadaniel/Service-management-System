package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BookingDBUtil {
	public static Connection createConnection() {
		Connection con = null;
		try {
			String driver="org.apache.derby.jdbc.EmbeddedDriver";
			
			Class.forName(driver);
			con = DriverManager.getConnection("jdbc:derby:C:\\Users\\USER\\MyDB;create=true");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		return con;
	}

	public static void closeAllConnection(Connection con, PreparedStatement ps, ResultSet rs) {
		try {
			if(rs!=null) {
				rs.close();
			}
			if(ps!=null) {
				ps.close();
			}
			if(con!=null) {
				con.close();
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		
	}
}
