package com.web;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.ServiceBooking;
import com.service.Service;

/**
 * Servlet implementation class BookingServlet
 */
@WebServlet("/ServiceBookingServlet")
public class ServiceBookingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ServiceBookingServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       HttpSession session = request.getSession();
       String user_id = (String) session.getAttribute("user_id");
       String serviceType = request.getParameter("service_type");
        String address = request.getParameter("address");
        String date = request.getParameter("date");
        String slot = request.getParameter("slot");
        String vendor = request.getParameter("vendor");
        String amountStr = request.getParameter("amount");

        RequestDispatcher rd = null;
        Service service = new Service();

        double amount = 0.0;
        try {
            if (amountStr != null && !amountStr.trim().isEmpty()) {
                amount = Double.parseDouble(amountStr);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            rd = request.getRequestDispatcher("Failure.jsp");
            rd.forward(request, response);
            return;
        }

        // Generate a random service ID
        int serviceId = (int) (Math.random() * 100000);

        // Create Booking object with generated service ID
        ServiceBooking booking = new ServiceBooking(Integer.parseInt(user_id),serviceId, serviceType, address, date, slot, vendor, amount);
        boolean result = service.addService(booking);

        if (result) {
            // Pass service ID and other details to JSP
            request.setAttribute("serviceId", serviceId);
            request.setAttribute("serviceType", serviceType);
            request.setAttribute("date", date);
            request.setAttribute("slot", slot);
            request.setAttribute("vendor", vendor);
            request.setAttribute("amount", amount);
            rd = request.getRequestDispatcher("acknowledgment.jsp");
        } else {
            rd = request.getRequestDispatcher("Failure.jsp");
        }

        rd.forward(request, response);
    }
}
