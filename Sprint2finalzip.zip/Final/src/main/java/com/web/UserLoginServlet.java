package com.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.UserLoginBean;
import com.service.UserLoginService;

@WebServlet("/UserLoginServlet")
public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Get login parameters
		String userID = request.getParameter("userID");
		String userPassword = request.getParameter("userPassword");

		// Create UserLoginBean object and set the parameters
		UserLoginBean user = new UserLoginBean();
		user.setUserID(userID);
		user.setUserPassword(userPassword);

		// Create service object to handle business logic
		UserLoginService userService = new UserLoginService();
		try {
			// Authenticate user and retrieve their name
			String userName = userService.authenticateUser(user);
			
			if (userName != null) {
				// User authenticated successfully, start session
				HttpSession session = request.getSession();
				
				// Store user ID and user name in session
				session.setAttribute("user_id", userID);
				session.setAttribute("user_name", userName);

				// Redirect to the user's home page
				request.getRequestDispatcher("UserHome.jsp").forward(request, response);
			} else {
				// Invalid credentials, send back to login page with error message
				request.setAttribute("errorMessage", "Invalid User ID or Password");
				request.getRequestDispatcher("UserLogin.jsp").forward(request, response);
			}
		} catch (SQLException e) {
			// Handle SQL exceptions and return error
			e.printStackTrace();
			request.setAttribute("errorMessage", "Something went wrong. Please try again.");
			request.getRequestDispatcher("UserLogin.jsp").forward(request, response);
		}
	}
}
