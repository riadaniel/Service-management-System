package com.web;

import com.bean.Booking;
import com.service.BookingService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/BookingServlet2")
public class BookingServlet2 extends HttpServlet {

    private static final int ROWS_PER_PAGE = 5;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session = request.getSession();
        String user_id = (String) session.getAttribute("user_id");

        // If user_id is not present in the session, redirect to login page
        if (user_id == null) {
            response.sendRedirect("UserLogin.jsp");
            return;
        }

        // Get the page number from the request parameter (if any)
        String pageParam = request.getParameter("page");

        // Initialize page number
        int pageNumber = 1;
        if (pageParam != null && !pageParam.isEmpty()) {
            try {
                pageNumber = Integer.parseInt(pageParam);
            } catch (NumberFormatException e) {
                request.setAttribute("error", "Invalid page number format.");
            }
        }

        // Create an instance of BookingService
        BookingService bookingService = new BookingService();

        // Fetch total number of bookings and calculate total pages
        int totalBookings = bookingService.getTotalBookingsCount(Integer.parseInt(user_id));
        int totalPages = (int) Math.ceil(totalBookings / (double) ROWS_PER_PAGE);

        // Fetch booking list for the specific customer with pagination
        List<Booking> bookingList = bookingService.getBookingListByCustId(Integer.parseInt(user_id), pageNumber, ROWS_PER_PAGE);

        // Set attributes for pagination and booking list
        request.setAttribute("bookings", bookingList);
        request.setAttribute("totalPages", totalPages);
        request.setAttribute("currentPage", pageNumber);
        request.setAttribute("user_id", user_id);

        // Forward the request to the JSP page
        request.getRequestDispatcher("view_list.jsp").forward(request, response);
    }
}
