package com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.service.Service;

@WebServlet("/UpdateServiceServlet")
public class UpdateServiceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public UpdateServiceServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String service_id = request.getParameter("service_id");

        if (service_id != null && !service_id.trim().isEmpty()) {
            // Update status in database
            Service service = new Service();
            boolean result = service.updateBookingStatus(service_id);

            if (result) {
                response.sendRedirect("updateserviceSuccess.jsp");
            } else {
                response.sendRedirect("updateServiceFailure.jsp");
            }
        } else {
            response.sendRedirect("booking_failure.jsp");
        }
    }
}
