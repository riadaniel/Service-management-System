package com.web;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.bean.AdminLoginBean;
import com.service.AdminLoginService;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AdminLoginServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Retrieve AdminID and Password from form
		String adminID = request.getParameter("adminID");
		String adminPassword = request.getParameter("adminPassword");

		// Create AdminLoginBean and set adminID and adminPassword
		AdminLoginBean admin = new AdminLoginBean();
		admin.setAdminID(adminID);
		admin.setAdminPassword(adminPassword);

		// Create service object and validate admin login
		AdminLoginService adminService = new AdminLoginService();
		boolean isValidAdmin = false;

		try {
			// Validate credentials
			isValidAdmin = adminService.validateAdmin(admin);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		// Check if valid admin, redirect accordingly
		if (isValidAdmin) {
			// Redirect to home.jsp on success
			response.sendRedirect("AdminHome.jsp");
		} else {
			// Redirect back to login page with error parameter on failure
			response.sendRedirect("AdminLogin.jsp?error=true");
		}
	}
}
