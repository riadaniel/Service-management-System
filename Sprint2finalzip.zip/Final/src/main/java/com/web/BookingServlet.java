package com.web;

import com.bean.Booking;
import com.dao.BookingDAO;
import com.service.BookingService;
import com.util.DBUtil;

import java.util.List;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/view_list")
public class BookingServlet extends HttpServlet {

    private static final int ROWS_PER_PAGE = 5;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the customer ID and page number from the request
        String custidParam = request.getParameter("user_id");
        String pageParam = request.getParameter("page");

        // Initialize page number
        int pageNumber = 1;
        if (pageParam != null && !pageParam.isEmpty()) {
            try {
                pageNumber = Integer.parseInt(pageParam);
            } catch (NumberFormatException e) {
                request.setAttribute("error", "Invalid page number format.");
            }
        }

        if (custidParam != null && !custidParam.isEmpty()) {
            try {
                int user_id = Integer.parseInt(custidParam);

                // Create an instance of BookingService
                BookingService bookingService = new BookingService();

                // Fetch total number of bookings and calculate total pages
                int totalBookings = BookingDAO.getTotalBookingsCount(DBUtil.getConnection(), user_id);
                int totalPages = (int) Math.ceil(totalBookings / (double) ROWS_PER_PAGE);

                // Fetch booking list for the specific customer with pagination
                List<Booking> bookingList = bookingService.getBookingListByCustId(user_id, pageNumber, ROWS_PER_PAGE);

                // Set attributes for pagination and booking list
                request.setAttribute("bookings", bookingList);
                request.setAttribute("totalPages", totalPages);
                request.setAttribute("currentPage", pageNumber);
                request.setAttribute("user_id", user_id);

            } catch (NumberFormatException e) {
                request.setAttribute("error", "Invalid Customer ID format.");
            }
        } else {
            request.setAttribute("error", "Customer ID is required.");
        }

        // Forward the request to the JSP page
        request.getRequestDispatcher("view_list.jsp").forward(request, response);
    }
}
