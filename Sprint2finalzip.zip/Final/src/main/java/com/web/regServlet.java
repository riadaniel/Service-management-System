package com.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.bean.reg;
import com.service.regservice;

/**
 * Servlet implementation class BookingServlet
 */
@WebServlet("/regServlet")
public class regServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public regServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userName = request.getParameter("userName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String address = request.getParameter("address");
        String contactNumber = request.getParameter("contactNumber");

        System.out.println("Received form data: " + userName + ", " + email + ", " + contactNumber); // Debugging output

        RequestDispatcher rd = null;
        regservice service = new regservice();

        // Generate a random user ID
        int userId = (int) Math.floor(1000000+Math.random()*9000000);

        // Check if the email is already registered
        boolean emailExists = false;
        try {
            emailExists = regservice.isEmailRegistered(email);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        if (emailExists) {
            // Log email already registered
            System.out.println("Email already exists: " + email); // Debugging output
            request.setAttribute("errorMessage", "This email is already registered. Please try logging in.");
            rd = request.getRequestDispatcher("Failure.jsp");
        } else {
            // Create a new customer registration object
            reg customer = new reg(userId, userName, email, password, address, contactNumber);

            // Try to add the customer to the database
            boolean result = false;
            try {
                result = regservice.addCustomer(customer);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

            if (result) {
                System.out.println("Customer registered successfully with ID: " + userId); // Debugging output
                // Customer registration was successful, forward to acknowledgment page
                request.setAttribute("userId", userId);
                request.setAttribute("userName", userName);
                request.setAttribute("email", email);
                request.setAttribute("password", password);
                request.setAttribute("address", address);
                request.setAttribute("contactNumber", contactNumber);
                rd = request.getRequestDispatcher("ack.jsp");
            } else {
                System.out.println("Customer registration failed."); // Debugging output
                // Registration failed, forward to failure page
                rd = request.getRequestDispatcher("Failure.jsp");
            }
        }

        rd.forward(request, response);
    }

}
