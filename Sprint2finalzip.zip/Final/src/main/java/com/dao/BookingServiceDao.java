package com.dao;

import java.sql.*;

import com.bean.ServiceBooking;
import com.dao.*;

import com.util.BookingDBUtil;

public class BookingServiceDao {
	public boolean addService(ServiceBooking b) {
		boolean result=false;
		try {
			Connection con = BookingDBUtil.createConnection();
			String sql="INSERT INTO bookings(user_id,service_id,service_type,address,date,slot,vendor,amount) VALUES (?,?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1,b.getUser_id());
			ps.setInt(2, b.getServiceId());
			ps.setString(3, b.getServiceType());
			ps.setString(4,b.getAddress());
			ps.setString(5,b.getDate());
			ps.setString(6,b.getSlot());
			ps.setString(7,b.getVendor());
			ps.setDouble(8,b.getAmount());
			int t = ps.executeUpdate();
			if(t>0) {
				result=true;
			}
			BookingDBUtil.closeAllConnection(con, ps, null);
		} catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		return result;
}

    public boolean updateBookingStatus(String service_id) {
        boolean result = false;
        try {
            Connection con = BookingDBUtil.createConnection();
            String sql = "UPDATE bookings SET status = 'Completed' WHERE service_id = ? ";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, service_id);
            int t = ps.executeUpdate();
            if (t > 0) {
                result = true;
            }
            BookingDBUtil.closeAllConnection(con, ps, null);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }
}
