package com.dao;

import com.bean.Booking;
//import com.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookingDAO {

    // Method to fetch booking details by customer ID with pagination
    public static List<Booking> getBookingByCustId(Connection conn, int user_id, int pageNumber, int rowsPerPage) {
        List<Booking> bookingList = new ArrayList<>();
        String sql = "SELECT * FROM ( " +
                     "    SELECT ROW_NUMBER() OVER () AS rownum, b.service_id, b.service_type, b.date, b.slot, b.address, " +
                     "    b.vendor, b.amount,b.status, c.user_name " +
                     "    FROM bookings b JOIN customers c ON b.user_id = c.user_id " +
                     "    WHERE b.user_id = ? " +
                     ") AS result " +
                     "WHERE rownum BETWEEN ? AND ?";

        if (conn == null) {
            System.out.println("Connection is null.");
            return bookingList; // return empty list if connection is null
        }

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
        	
            ps.setInt(1, user_id); // Set the customer ID in the query
            int startRow = (pageNumber - 1) * rowsPerPage + 1;
            int endRow = pageNumber * rowsPerPage;
            ps.setInt(2, startRow);
            ps.setInt(3, endRow);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                // Retrieve service and customer details from the result set
                int serviceId = rs.getInt("service_id");
                String serviceType = rs.getString("service_type");
                Date serviceDate = rs.getDate("date");
                String serviceSlot = rs.getString("slot");
                String address = rs.getString("address");
                String vendor = rs.getString("vendor");
                double amount = rs.getDouble("amount");
                String status = rs.getString("status");
                String customerName = rs.getString("user_name");

                // Create a new Booking object and add it to the list
                Booking booking = new Booking(serviceId, serviceType, serviceDate, serviceSlot, address, vendor, amount,status, customerName);
                bookingList.add(booking);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bookingList;
    }

    // Method to get the total number of bookings for pagination
    public static int getTotalBookingsCount(Connection conn, int user_id) {
        String sql = "SELECT COUNT(*) FROM bookings WHERE user_id = ?";
        int count = 0;

        if (conn == null) {
            System.out.println("Connection is null.");
            return count; // return 0 if connection is null
        }

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, user_id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return count;
    }
}
