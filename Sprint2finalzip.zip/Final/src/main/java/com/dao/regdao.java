package com.dao;

import java.sql.*;

import com.bean.*;
import com.dao.*;

import com.util.*;

public class regdao {
	public boolean addCustomer(reg b) {
	    boolean result = false;
	    try {
	        Connection con = derbyUtil.createConnection();
	        String sql = "INSERT INTO customers(user_id, user_name, email, password, address, contact) VALUES (?,?,?,?,?,?)";
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.setInt(1, b.getUserId());
	        ps.setString(2, b.getUserName());
	        ps.setString(3, b.getEmail());
	        ps.setString(4, b.getPassword());
	        ps.setString(5, b.getAddress());
	        ps.setString(6, b.getContactNumber());
	        int t = ps.executeUpdate();
	        if (t > 0) {
	            result = true;
	        }
	        derbyUtil.closeAllConnection(con, ps, null);
	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	    }
	    return result;
	}

}
