package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.UserLoginBean;
import com.util.UserLoginUtil;

public class UserLoginDAO {
    
    // This method will return the user's name if authentication is successful, else return null.
    public String validateUser(UserLoginBean user) throws SQLException {
        String userName = null;
        String query = "SELECT user_name FROM customers WHERE user_id = ? AND password = ?";

        try (Connection con = UserLoginUtil.getConnection();
                PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, user.getUserID());
            ps.setString(2, user.getUserPassword());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    // User is valid, retrieve user name
                    userName = rs.getString("user_name");
                }
            }
        }
        return userName; // If null, it means invalid credentials
    }
}
