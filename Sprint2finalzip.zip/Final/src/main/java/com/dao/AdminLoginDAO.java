package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.bean.AdminLoginBean;
import com.util.AdminLoginUtil;

public class AdminLoginDAO {

	public boolean isValidAdmin(AdminLoginBean admin) throws SQLException {
		// SQL query to check if the admin ID and password match the database
		String query = "SELECT * FROM admin WHERE id = ? AND password = ?";
		Connection con = AdminLoginUtil.getConnection();

		try {
			// Prepare the statement and set parameters
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, admin.getAdminID());
			ps.setString(2, admin.getAdminPassword());

			// Execute the query
			ResultSet rs = ps.executeQuery();

			// Return true if a match is found, otherwise false
			return rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				con.close(); // Close the connection
			}
		}
		return false;
	}
}
