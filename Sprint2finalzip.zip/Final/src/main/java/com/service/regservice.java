package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.bean.reg;
import com.util.*;

public class regservice {

    public static boolean addCustomer(reg customer) throws ClassNotFoundException {
        boolean isAdded = false;
        try (Connection con = derbyUtil.createConnection()) {
            String query = "INSERT INTO customers (user_id, user_name, email, password, address, contact) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setInt(1, customer.getUserId());
            pstmt.setString(2, customer.getUserName());
            pstmt.setString(3, customer.getEmail());
            pstmt.setString(4, customer.getPassword());
            pstmt.setString(5, customer.getAddress());
            pstmt.setString(6, customer.getContactNumber());
            
            int row = pstmt.executeUpdate();
            isAdded = row > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isAdded;
    }

    // Method to check if the email is already registered
    public static boolean isEmailRegistered(String email) throws ClassNotFoundException {
        boolean emailExists = false;
        try (Connection con = derbyUtil.createConnection()) {
            String query = "SELECT email FROM customers WHERE email = ?";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                emailExists = true; // Email already exists in the database
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return emailExists;
    }
}
