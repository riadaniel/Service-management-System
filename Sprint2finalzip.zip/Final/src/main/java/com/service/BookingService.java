package com.service;

import com.bean.Booking;
import com.dao.BookingDAO;
import com.util.DBUtil;

import java.sql.Connection;
import java.util.List;

public class BookingService {

    // Method to get paginated booking list for a specific customer ID
    public List<Booking> getBookingListByCustId(int user_id, int pageNumber, int rowsPerPage) {
        List<Booking> bookingList = null;
        try (Connection conn = DBUtil.getConnection()) {
            // Fetch booking list by customer ID with pagination
            bookingList = BookingDAO.getBookingByCustId(conn, user_id, pageNumber, rowsPerPage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bookingList;
    }

    // Method to get the total number of bookings for a specific customer ID
    public int getTotalBookingsCount(int user_id) {
        int totalBookings = 0;
        try (Connection conn = DBUtil.getConnection()) {
            // Get total count of bookings for the customer
            totalBookings = BookingDAO.getTotalBookingsCount(conn, user_id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return totalBookings;
    }
}
