package com.service;

import java.sql.SQLException;

import com.bean.AdminLoginBean;
import com.dao.AdminLoginDAO;

public class AdminLoginService {
	private AdminLoginDAO adminDAO = new AdminLoginDAO();
	
	public boolean validateAdmin(AdminLoginBean admin) throws SQLException {
		return adminDAO.isValidAdmin(admin);
	}
}
