package com.service;

import com.bean.ServiceBooking;
import com.dao.BookingServiceDao;

public class Service {
	public boolean addService(ServiceBooking b) {
		BookingServiceDao dao = new BookingServiceDao();
		return dao.addService(b);
	}
    public boolean updateBookingStatus(String service_id) {
        BookingServiceDao dao = new BookingServiceDao();
        return dao.updateBookingStatus(service_id);
    }

}
