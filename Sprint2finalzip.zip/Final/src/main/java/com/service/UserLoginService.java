package com.service;

import java.sql.SQLException;

import com.bean.UserLoginBean;
import com.dao.UserLoginDAO;

public class UserLoginService {
	private UserLoginDAO userDAO = new UserLoginDAO();

	public String authenticateUser(UserLoginBean user) throws SQLException {
		return userDAO.validateUser(user);
	}
	
}
