package com.bean;

public class AdminLoginBean{
	private String adminID;
	private String adminPassword;
	
	//getter
	public String getAdminID() {
		return adminID;
	}
	
	public String getAdminPassword() {
		return adminPassword;
	}
	
	//setter
	public void setAdminID(String adminID) {
		this.adminID=adminID;
	}
	
	public void setAdminPassword(String adminPassword) {
		this.adminPassword=adminPassword;
	}
}

