package com.bean;

public class UserLoginBean {
	private String userID;
    private String userPassword;

    // Getters
    public String getUserID() {
        return userID;
    }
    
    public String getUserPassword() {
        return userPassword;
    }
    
    // Setters
    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }
}
