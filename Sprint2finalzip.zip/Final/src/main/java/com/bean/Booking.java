package com.bean;

import java.sql.Date;

public class Booking {
    private int serviceId;
    private String serviceType;
    private Date serviceDate;
    private String serviceSlot;
    private String address;
    private String vendor;
    private double amount;
    private String status;
    private String customerName;

    // Constructor
    public Booking(int serviceId, String serviceType, Date serviceDate, String serviceSlot, 
                   String address, String vendor, double amount,String status, String customerName) {
        this.serviceId = serviceId;
        this.serviceType = serviceType;
        this.serviceDate = serviceDate;
        this.serviceSlot = serviceSlot;
        this.address = address;
        this.vendor = vendor;
        this.amount = amount;
        this.status=status;
        this.customerName = customerName;
    }

    public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	// Getters
    public int getServiceId() {
        return serviceId;
    }

    public String getServiceType() {
        return serviceType;
    }

    public Date getServiceDate() {
        return serviceDate;
    }

    public String getServiceSlot() {
        return serviceSlot;
    }

    public String getAddress() {
        return address;
    }

    public String getVendor() {
        return vendor;
    }

    public double getAmount() {
        return amount;
    }

    public String getCustomerName() {
        return customerName;
    }

    // Setters
    public void setServiceId(int serviceId) {
        this.serviceId = serviceId;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public void setServiceDate(Date serviceDate) {
        this.serviceDate = serviceDate;
    }

    public void setServiceSlot(String serviceSlot) {
        this.serviceSlot = serviceSlot;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
}
