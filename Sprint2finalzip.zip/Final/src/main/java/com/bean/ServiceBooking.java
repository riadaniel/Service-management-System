package com.bean;

public class ServiceBooking {
	private int user_id;
	private int serviceId;
	private String serviceType;
	private String address;
	private String date;
	private String slot;
	private String vendor;
	private double amount;
	
	 public ServiceBooking( int user_id,int serviceId,String serviceType,String address, String date, String slot, String vendor, double amount) {
	     this.user_id = user_id;   
		 this.serviceId = serviceId;
	        this.serviceType = serviceType;
	        this.address=address;
	        this.date = date;
	        this.slot = slot;
	        this.vendor = vendor;
	        this.amount = amount;
	    }
	
	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		vendor = vendor;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		amount = amount;
	}

}
